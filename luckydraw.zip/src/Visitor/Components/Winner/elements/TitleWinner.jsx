import React from 'react'

function TitleWinner() {
  return (
    <div>
        <div className="my-5">
                <h1 className="p-3 text-center fw-bold backgroundText2">
                    ເລກບິນຜູ້ໂຊກດີ
                </h1>
            </div>
    </div>
  )
}

export default TitleWinner