import React from 'react'
import reward from '../../../../Assets/icon/reward.png'

function ImageOfMedal() {
  return (
    <div>
        <img width={150} className="d-block mx-auto py-5" src={reward} alt="" />
    </div>
  )
}

export default ImageOfMedal