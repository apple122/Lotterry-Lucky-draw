import React from 'react'

function TitleSecondPlace() {
    return (
        <div>
            <div className="my-2 d-block mx-auto">
                <h4 className="p-3 text-center fw-bold fs-1">
                    ລາງວັນ 500,000 ກີບ
                </h4>
            </div>
        </div>
    )
}

export default TitleSecondPlace