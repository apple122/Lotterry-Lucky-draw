import React from 'react'

function TopBox() {
  return (
    <div>
        <div className='text-center text-white top'>
              SBS Trade is the best choice for your life
            </div>
    </div>
  )
}

export default TopBox