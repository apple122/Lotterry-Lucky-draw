import React from 'react'

function Title() {
  return (
    <div>
        <h1 className="my-4 p-3 text-center fw-bold fs-2 backgroundText1">
          Spin ສຸ່ມລຸ້ນໂຊກ
        </h1>
    </div>
  )
}

export default Title