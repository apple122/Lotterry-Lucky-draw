import React from 'react'

function Marquee() {
  return (
    <div>
        <marquee behavior="scroll" direction="left" > <h2 className='text-danger mt-3'></h2>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos alias voluptatem doloremque aperiam aliquam optio repudiandae aspernatur pariatur quas, temporibus tempore provident quibusdam qui quidem iure in repellat voluptatum. Labore.</marquee>
    </div>
  )
}

export default Marquee