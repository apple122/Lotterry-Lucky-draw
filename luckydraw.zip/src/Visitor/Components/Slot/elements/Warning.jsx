import React, {useState} from 'react'

function Warning() {
    
  return (
    <div>
        <p className="mt-3 text-center fs-3 fw-bold warningAnimation">ກະລຸນາເລືອກລາງວັນ ຫລື ປ້ອນງວດໃຫ້ຄົບ</p> 
    </div>
  )
}

export default Warning