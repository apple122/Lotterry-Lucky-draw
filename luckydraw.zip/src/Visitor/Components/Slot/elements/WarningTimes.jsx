import React from 'react'

function WarningTimes() {
  return (
    <div>
        <p className="mt-3 text-center fs-3 fw-bold warningAnimation">ກະລຸນາປ້ອນ ຫລື ເລື້ອກຂໍ້ມູນໃຫ້ຄົບ</p> 
    </div>
  )
}

export default WarningTimes