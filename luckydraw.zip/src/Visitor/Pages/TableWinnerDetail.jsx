import React from 'react'
import TableWinnerDetailComponent from '../Components/TableOfLuckyPeopleDetail/TableWinnerDetailComponent'

function TableWinnerDetail() {
  return (
    <div><TableWinnerDetailComponent/></div>
  )
}

export default TableWinnerDetail