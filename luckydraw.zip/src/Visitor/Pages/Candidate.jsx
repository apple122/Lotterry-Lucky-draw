import React from 'react'
import ListOfCandidate from '../Components/Candidate/ListOfCandidate'

function ListOfNameWhoIsSelected() {
  window.scrollTo(0, 0)
  return (
    <div>
     <ListOfCandidate/>
    </div>
  )
}

export default ListOfNameWhoIsSelected