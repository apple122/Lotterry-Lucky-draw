import React from 'react'
import LoginForm from '../Components/LoginForm/LoginForm'


function LoginPage() {  
  window.scrollTo(0, 0)
  return (
    <div>
     <LoginForm/>
    </div>
  )
}

export default LoginPage